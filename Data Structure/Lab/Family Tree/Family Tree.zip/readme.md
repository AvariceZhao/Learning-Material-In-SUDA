# FamilyTree 

---

本实验利用树相关的知识解决了给定的算法题目



## 附件说明

1. `main.cpp`：主程序
2. `Tree.h`：声明解决此问题用到的树类
3. `Tree.cpp`:实现解决此问题的树类的相关功能
4. `out.txt`：对于给定的family.txt输入数据相应的输出结果



## 测试环境

**Windows 11,Visual Studio 2022**



## 使用方法

使用Visual Studio新建C++控制台程序，将.h添加到头文件，将cpp文件添加到源文件，在右侧源文件中选择main.cpp生成解决方案并执行。


